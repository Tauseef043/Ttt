export const colors = {
  bg: '#F4F6FA',
  card: '#FFFFFF',
  primary: '#2563EB',
  primarySoft: '#DBEAFE',
  text: '#0F172A',
  muted: '#64748B',
  border: '#E2E8F0',
  danger: '#DC2626',
  dangerSoft: '#FEE2E2',
  green: '#16A34A',
  greenSoft: '#DCFCE7',
};
