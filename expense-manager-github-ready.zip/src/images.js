import { useEffect, useRef, useState } from 'react';
import { Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';

const DIR = FileSystem.documentDirectory + 'attachments/';

async function persistImage(srcUri) {
  await FileSystem.makeDirectoryAsync(DIR, { intermediates: true }).catch(() => {});
  const dest = DIR + Date.now() + '_' + Math.floor(Math.random() * 100000) + '.jpg';
  await FileSystem.copyAsync({ from: srcUri, to: dest });
  return dest;
}

export async function pickImage(fromCamera) {
  if (fromCamera) {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Camera permission needed', 'Allow camera access in Settings to take a photo.');
      return null;
    }
  }
  const opts = { mediaTypes: ['images'], quality: 0.7 };
  const res = fromCamera
    ? await ImagePicker.launchCameraAsync(opts)
    : await ImagePicker.launchImageLibraryAsync(opts);
  if (res.canceled || !res.assets || !res.assets.length) return null;
  return persistImage(res.assets[0].uri);
}

export async function deleteImage(uri) {
  if (uri && uri.startsWith(DIR)) {
    await FileSystem.deleteAsync(uri, { idempotent: true }).catch(() => {});
  }
}

export async function deleteImages(uris) {
  for (const u of uris) {
    await deleteImage(u);
  }
}

// Keeps the attachment of a form. Images chosen but never saved are cleaned up,
// and the old image is removed once a replacement has been saved.
export function useAttachment(initial) {
  const original = useRef(initial || null);
  const saved = useRef(false);
  const [image, setImage] = useState(initial || null);
  const [busy, setBusy] = useState(false);
  const imageRef = useRef(image);
  imageRef.current = image;

  useEffect(() => {
    return () => {
      if (!saved.current && imageRef.current && imageRef.current !== original.current) {
        deleteImage(imageRef.current);
      }
    };
  }, []);

  const pick = async (fromCamera) => {
    if (busy) return;
    setBusy(true);
    try {
      const uri = await pickImage(fromCamera);
      if (uri) {
        if (image && image !== original.current) await deleteImage(image);
        setImage(uri);
      }
    } catch (e) {
      Alert.alert('Could not add image', String((e && e.message) || e));
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (image && image !== original.current) await deleteImage(image);
    setImage(null);
  };

  const commit = async () => {
    saved.current = true;
    if (original.current && original.current !== image) await deleteImage(original.current);
  };

  return { image, busy, pick, remove, commit };
}
