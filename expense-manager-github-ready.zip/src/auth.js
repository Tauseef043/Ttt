import * as Crypto from 'expo-crypto';
import * as SecureStore from 'expo-secure-store';
import { findUserByName, findUserById, insertUser } from './db';

const SESSION_KEY = 'em_session_user_id';
const ROUNDS = 50;

async function hashPassword(salt, password) {
  let h = salt + ':' + password;
  for (let i = 0; i < ROUNDS; i++) {
    h = await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, h + salt);
  }
  return h;
}

const clean = (u) => String(u || '').trim().toLowerCase();

export async function signUp(usernameRaw, password) {
  const username = clean(usernameRaw);
  if (username.length < 3) throw new Error('Username must be at least 3 characters.');
  if (!/^[a-z0-9_.@-]+$/.test(username)) {
    throw new Error('Username can only contain letters, numbers and . _ - @');
  }
  if (!password || password.length < 4) throw new Error('Password must be at least 4 characters.');
  if (findUserByName(username)) throw new Error('This username is already taken.');

  const salt = Crypto.randomUUID();
  const hash = await hashPassword(salt, password);
  const id = insertUser(username, salt, hash);
  await SecureStore.setItemAsync(SESSION_KEY, String(id));
  return { id, username };
}

export async function logIn(usernameRaw, password) {
  const username = clean(usernameRaw);
  const row = findUserByName(username);
  if (!row) throw new Error('Wrong username or password.');
  const hash = await hashPassword(row.salt, password || '');
  if (hash !== row.password_hash) throw new Error('Wrong username or password.');
  await SecureStore.setItemAsync(SESSION_KEY, String(row.id));
  return { id: row.id, username: row.username };
}

export async function restoreSession() {
  const id = await SecureStore.getItemAsync(SESSION_KEY);
  if (!id) return null;
  const row = findUserById(Number(id));
  return row ? { id: row.id, username: row.username } : null;
}

export async function logOut() {
  await SecureStore.deleteItemAsync(SESSION_KEY);
}
