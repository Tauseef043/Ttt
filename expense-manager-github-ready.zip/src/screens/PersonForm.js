import React, { useState } from 'react';
import { Alert, ScrollView } from 'react-native';
import { useApp } from '../AppContext';
import { addPerson, getPerson, updatePerson } from '../db';
import { Button, Field, Screen } from '../ui';

export default function PersonForm({ params }) {
  const { user, nav, bump } = useApp();
  const editing = params && params.id ? getPerson(params.id, user.id) : null;
  const [name, setName] = useState(editing ? editing.name : '');
  const [phone, setPhone] = useState(editing ? editing.phone || '' : '');

  const save = () => {
    if (!name.trim()) return Alert.alert('Name required', 'Please enter the person\'s name.');
    const data = { name: name.trim(), phone: phone.trim() };
    if (editing) {
      updatePerson(editing.id, user.id, data);
      bump();
      nav.pop();
    } else {
      const id = addPerson(user.id, data);
      bump();
      // replace the form with the new person's profile
      nav.pop();
      nav.push('PersonDetail', { id });
    }
  };

  return (
    <Screen title={editing ? 'Edit person' : 'Add person'} onBack={() => nav.pop()}>
      <ScrollView contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
        <Field label="Name" value={name} onChangeText={setName} placeholder="e.g. Ali" autoCapitalize="words" />
        <Field label="Phone (optional)" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="03xx xxxxxxx" />
        <Button title="Save" onPress={save} />
      </ScrollView>
    </Screen>
  );
}
