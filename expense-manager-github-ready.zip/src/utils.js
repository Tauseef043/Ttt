import { CURRENCY } from './constants';

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];
const MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const pad = (n) => (n < 10 ? '0' + n : String(n));

export function money(n) {
  const v = Math.round((Number(n) || 0) * 100) / 100;
  const parts = Math.abs(v).toFixed(2).split('.');
  const whole = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const text = parts[1] === '00' ? whole : whole + '.' + parts[1];
  return (v < 0 ? '-' : '') + CURRENCY + ' ' + text;
}

export function parseAmount(str) {
  const n = Number(String(str || '').replace(/,/g, '').trim());
  return Number.isFinite(n) ? n : NaN;
}

export function todayISO() {
  const d = new Date();
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}

export function isValidDate(str) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(str)) return false;
  const [y, m, d] = str.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
}

export function shiftDate(iso, days) {
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(y, m - 1, d + days);
  return dt.getFullYear() + '-' + pad(dt.getMonth() + 1) + '-' + pad(dt.getDate());
}

export function prettyDate(iso) {
  if (!isValidDate(iso)) return iso;
  const [y, m, d] = iso.split('-').map(Number);
  return d + ' ' + MONTHS_SHORT[m - 1] + ' ' + y;
}

export function monthKey(iso) {
  return iso.slice(0, 7);
}

export function monthLabel(key) {
  const [y, m] = key.split('-').map(Number);
  return MONTHS[m - 1] + ' ' + y;
}

export function shiftMonth(key, delta) {
  const [y, m] = key.split('-').map(Number);
  const dt = new Date(y, m - 1 + delta, 1);
  return dt.getFullYear() + '-' + pad(dt.getMonth() + 1);
}

export function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

// Net position with one person.
// > 0  : the person owes me   (I will get)
// < 0  : I owe the person     (I will pay)
export function balanceOf(t) {
  return round2(t.given - t.received - (t.borrowed - t.paid));
}

export function balanceInfo(balance, colors) {
  if (balance > 0.004) return { text: "You'll get " + money(balance), color: colors.green };
  if (balance < -0.004) return { text: 'You owe ' + money(-balance), color: colors.danger };
  return { text: 'Settled', color: colors.muted };
}
