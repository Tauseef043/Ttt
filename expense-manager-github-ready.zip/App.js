import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, BackHandler, StyleSheet, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AppCtx } from './src/AppContext';
import { restoreSession, logOut } from './src/auth';
import { colors } from './src/theme';
import AuthScreen from './src/screens/AuthScreen';
import HomeScreen from './src/screens/HomeScreen';
import ExpenseForm from './src/screens/ExpenseForm';
import PersonForm from './src/screens/PersonForm';
import PersonDetail from './src/screens/PersonDetail';
import TxnForm from './src/screens/TxnForm';

const SCREENS = {
  Home: HomeScreen,
  ExpenseForm,
  PersonForm,
  PersonDetail,
  TxnForm,
};

const HOME = { key: 'home', name: 'Home', params: {} };

function Root() {
  const [booting, setBooting] = useState(true);
  const [user, setUser] = useState(null);
  const [version, setVersion] = useState(0);
  const [stack, setStack] = useState([HOME]);
  const counter = useRef(1);

  useEffect(() => {
    (async () => {
      try {
        setUser(await restoreSession());
      } catch (e) {
        setUser(null);
      }
      setBooting(false);
    })();
  }, []);

  const nav = useMemo(
    () => ({
      push: (name, params) =>
        setStack((st) => [...st, { key: name + '-' + counter.current++, name, params: params || {} }]),
      pop: (n) =>
        setStack((st) => {
          const count = n || 1;
          return st.length > count ? st.slice(0, st.length - count) : [st[0]];
        }),
    }),
    []
  );

  const bump = useCallback(() => setVersion((v) => v + 1), []);

  const onAuth = useCallback((u) => {
    setStack([HOME]);
    setUser(u);
  }, []);

  const logout = useCallback(async () => {
    await logOut();
    setStack([HOME]);
    setUser(null);
  }, []);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (stack.length > 1) {
        nav.pop();
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, [stack.length, nav]);

  const ctx = useMemo(() => ({ user, nav, version, bump, logout }), [user, nav, version, bump, logout]);

  if (booting) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!user) {
    return <AuthScreen onAuth={onAuth} />;
  }

  return (
    <AppCtx.Provider value={ctx}>
      <View style={{ flex: 1 }}>
        {stack.map((entry, i) => {
          const Comp = SCREENS[entry.name];
          const isTop = i === stack.length - 1;
          return (
            <View
              key={entry.key}
              style={[StyleSheet.absoluteFill, !isTop && { display: 'none' }]}
              pointerEvents={isTop ? 'auto' : 'none'}
            >
              <Comp params={entry.params} />
            </View>
          );
        })}
      </View>
    </AppCtx.Provider>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <Root />
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg },
});
